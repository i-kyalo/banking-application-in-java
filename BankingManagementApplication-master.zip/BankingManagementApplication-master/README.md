# BankingManagementApplication

A simple Java swing application demonstrating a banking system.

## To set-up:

1. Clone this repository
2. Open the folder in netbeans
3. In `javaconnect.java` change the path of sqlite db according to your system.
4. Build the project and then run Authentication.java to run the app.

## Contributors

List of contributors can be found in [Contributors.md](./Contributors.md).
